/**
 *@author jymane
 *Class Function:Service Implementation
 */
package com.cg.employee.service;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.employee.dao.IEmployeeDAO;
import com.cg.employee.dto.EmployeeDetails;
import com.cg.employee.dto.EmployeeLeaveDetails;

@Service("employeeservice")
@Transactional
public class EmployeeServiceImpl implements IEmployeeService 
{
	
	@Autowired
	IEmployeeDAO employeedao;

	/* Retrive All the List of Leave Details for Corresponding 
	 * Employee Id */
	@Override
	public List<EmployeeLeaveDetails> getEmployeeLeaveDeatils(Long empId) 
	{
		return employeedao.getEmployeeLeaveDeatils(empId);
	}

	/*Function which validate whether entered empId 
	 * is Exits or Not In database**********/
	@Override
	public boolean validateEmployeeId(long empId) {
		List<Long> getEmpIds=employeedao.getAllEmployeeIds();
		for(Long temp:getEmpIds)
		{
			System.out.println(temp);
			if(empId==temp)
				return true;
		}
		return false;
	}
	/*Function which validate whether entered empId 
	 * is Exits or Not In EmployeeLeaveTable and returns 
	 * the count for the same**********/
	@Override
	public EmployeeDetails getEmpName(long empId) {

		return employeedao.getEmpName(empId);
	}

	@Override
	public int validateEmployeeLeave(long empId) {
		int count=0;
		List<EmployeeLeaveDetails> empLeaveDetail=employeedao.getAllEmployeeLeaveDeatils();
		for(EmployeeLeaveDetails emp:empLeaveDetail)
		{
			if(emp.getEmpId()==empId)
			{
				count++;
			}
		}

		return count;
	}

}
