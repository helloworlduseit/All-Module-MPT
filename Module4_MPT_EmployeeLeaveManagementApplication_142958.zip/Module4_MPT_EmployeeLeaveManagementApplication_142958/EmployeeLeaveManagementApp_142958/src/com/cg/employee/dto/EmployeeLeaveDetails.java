/*
 * EmployeeLeaveDetails Bean class
 * */
package com.cg.employee.dto;

import java.io.Serializable;
import java.time.LocalDate;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
@Entity
@Table(name="employee_leave_details ")
public class EmployeeLeaveDetails implements Serializable
{
	/*Declaration of Class Attributes*/
	@Id
	@Column(name="leave_id")
	private Integer leaveId;
	
	@Column(name="empid")
	private Long empId;
	
	@Column(name="start_date")
	private String startDate;
	
	@Column(name="end_date")
	private String endDate;
	
	@Column(name="description")
	private String description;
	
	@Column(name="leaves_applied")
	private Integer leavesApplied;
	
	/**************Getter and Setter*************/
	public Integer getLeaveId() {
		return leaveId;
	}
	public void setLeaveId(Integer leaveId) {
		this.leaveId = leaveId;
	}
	public Long getEmpId() {
		return empId;
	}
	public void setEmpId(Long empId) {
		this.empId = empId;
	}
	
	public String getStartDate() {
		return startDate;
	}
	public void setStartDate(String startDate) {
		this.startDate = startDate;
	}
	public String getEndDate() {
		return endDate;
	}
	public void setEndDate(String endDate) {
		this.endDate = endDate;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public Integer getLeavesApplied() {
		return leavesApplied;
	}
	public void setLeavesApplied(Integer leavesApplied) {
		this.leavesApplied = leavesApplied;
	}
	
	
	

}
