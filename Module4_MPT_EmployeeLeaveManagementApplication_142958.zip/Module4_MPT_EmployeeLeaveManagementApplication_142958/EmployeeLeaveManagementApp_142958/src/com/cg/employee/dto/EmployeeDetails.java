/*
 * EmployeeDetails Bean class
 * */
package com.cg.employee.dto;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="employee_details")
public class EmployeeDetails implements Serializable
{
	/***Declaration of Class Attributes***/
	@Id
	@Column(name="empid")
	private Long empId;
	@Column(name="ename")
	private String empName;
	@Column(name="address")
	private String empAddress;
	@Column(name="leaves_avail")
	private Integer empLeaveAvail;
	
	/***********Getter and Setter*************/
	public Long getEmpId() {
		return empId;
	}
	public void setEmpId(Long empId) {
		this.empId = empId;
	}
	public String getEmpName() {
		return empName;
	}
	public void setEmpName(String empName) {
		this.empName = empName;
	}
	public String getEmpAddress() {
		return empAddress;
	}
	public void setEmpAddress(String empAddress) {
		this.empAddress = empAddress;
	}
	public Integer getEmpLeaveAvail() {
		return empLeaveAvail;
	}
	public void setEmpLeaveAvail(Integer empLeaveAvail) {
		this.empLeaveAvail = empLeaveAvail;
	}
	
	
	

}
