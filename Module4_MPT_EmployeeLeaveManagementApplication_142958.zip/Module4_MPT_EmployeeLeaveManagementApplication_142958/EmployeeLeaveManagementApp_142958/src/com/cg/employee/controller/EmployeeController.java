/**
 *@author jymane
 *Class Function:Controller
 */
package com.cg.employee.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.cg.employee.dto.EmployeeDetails;
import com.cg.employee.dto.EmployeeLeaveDetails;
import com.cg.employee.service.IEmployeeService;

@Controller
public class EmployeeController {

	@Autowired
	IEmployeeService employeeservice;
	
	@RequestMapping(value="viewdetails", method=RequestMethod.GET)
	public ModelAndView retrieveData(@RequestParam("empId") long empIdd)
	{

		ModelAndView mv = new ModelAndView();
		try {
			if(employeeservice.validateEmployeeId(empIdd))
			{
				/*After Validating EmpId*/
				EmployeeDetails edetail=employeeservice.getEmpName(empIdd);
				mv.addObject("empDetail", edetail);
				int count=employeeservice.validateEmployeeLeave(empIdd);
				if(count!=0)
				{
					/*If EmpId is Exits In EmployeeLeaveDetails*/
					List<EmployeeLeaveDetails> empLeaveDetails2=employeeservice.getEmployeeLeaveDeatils(empIdd);
					mv.addObject("temp",empLeaveDetails2);
					mv.addObject("error",count);
					mv.setViewName("ViewLeaveDetails");
				}
				else
				{
					/*If EmpId is Not Exits In EmployeeLeaveDetails*/
					mv.addObject("error",count);
					mv.addObject("temp", "No Leave record Found");
					mv.setViewName("ViewLeaveHistory");
				}
			}
			else{
				/*If EmpId Not Exits*/
				mv.addObject("temp","This Employee ID Does not exist..");
				mv.setViewName("Home");
			}
		}
		catch (Exception e) 
		{
			mv.addObject("temp",e.getMessage());
			mv.setViewName("Error");
		}
		return mv;
	}
}
