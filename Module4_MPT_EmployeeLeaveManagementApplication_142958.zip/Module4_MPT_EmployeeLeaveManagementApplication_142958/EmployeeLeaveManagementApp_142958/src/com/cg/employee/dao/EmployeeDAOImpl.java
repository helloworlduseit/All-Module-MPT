/*
 * /*Author:Jymane
 * Employee Dao Interface 
 * All functionalty which deals with database is Implemented here
 */

package com.cg.employee.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.persistence.TypedQuery;

import org.springframework.stereotype.Repository;

import com.cg.employee.dao.IEmployeeDAO;
import com.cg.employee.dto.EmployeeDetails;
import com.cg.employee.dto.EmployeeLeaveDetails;

@Repository("employeedao")
public class EmployeeDAOImpl implements IEmployeeDAO {

	@PersistenceContext
	EntityManager entitymanager;
	/*This function Takes EmpID and returns Employee Leave Details Corresponding to that
	 * Id*/
	@Override
	public List<EmployeeLeaveDetails> getEmployeeLeaveDeatils(long empId) {
		System.out.println(empId);
		String q1="FROM EmployeeLeaveDetails empLeaveDetail WHERE empLeaveDetail.empId=:eid";
		TypedQuery<EmployeeLeaveDetails> query1=entitymanager.createQuery(q1,EmployeeLeaveDetails.class);
		query1.setParameter("eid", empId);
		return query1.getResultList();
	}
	/*Returns All EmpIds From EmployeeDetails Table*/
	@Override
	public List<Long> getAllEmployeeIds() {
		String q1="SELECT empDetail.empId FROM EmployeeDetails empDetail";
		Query query2=entitymanager.createQuery(q1);
		return query2.getResultList();
	}
	/*Returns Details of Employee from EmployeeDetails corresponds to EmpId*/
	@Override
	public EmployeeDetails getEmpName(long empId) {
		String q1="SELECT empDetail FROM EmployeeDetails empDetail WHERE empDetail.empId=:eid";
		TypedQuery<EmployeeDetails> query3=entitymanager.createQuery(q1,EmployeeDetails.class);
		query3.setParameter("eid", empId);
		
		return query3.getSingleResult();
	}
	/*Returns All EmpIds From EmployeeLeaveDetails Table*/
	@Override
	public List<EmployeeLeaveDetails> getAllEmployeeLeaveDeatils() {
		Query query=entitymanager.createQuery("FROM EmployeeLeaveDetails");
		return query.getResultList();
	}

}
