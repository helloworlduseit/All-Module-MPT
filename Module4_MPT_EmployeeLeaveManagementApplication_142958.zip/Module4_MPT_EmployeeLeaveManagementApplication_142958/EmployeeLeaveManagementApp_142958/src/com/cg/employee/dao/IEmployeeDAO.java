/*Author:Jymane
 * Employee Dao Interface 
 * All functionalty which deals with database is Declared here
 */
package com.cg.employee.dao;

import java.util.List;

import com.cg.employee.dto.EmployeeDetails;
import com.cg.employee.dto.EmployeeLeaveDetails;

public interface IEmployeeDAO 
{

	public List<EmployeeLeaveDetails> getEmployeeLeaveDeatils(long empId);
	public List<Long> getAllEmployeeIds();
	public EmployeeDetails getEmpName(long empId);
	public List<EmployeeLeaveDetails> getAllEmployeeLeaveDeatils();
	
}
