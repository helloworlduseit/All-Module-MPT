package com.cg.booking.service;

import java.util.List;

import com.cg.booking.dto.ShowDetails;
import com.cg.booking.exception.BookingException;

public interface ShowService
{
	List<ShowDetails> getAllShowDetails() throws BookingException;
	int UpdateShowDetails(String showId,float noOfSeats) throws BookingException;
}
