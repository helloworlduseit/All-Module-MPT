package com.cg.booking.dto;

import java.time.LocalDate;

public class ShowDetails 
{
	private String showId;
	private String showName;
	private String location;
	private LocalDate date;
	private int availTicket;
	private float priceTicket;
	/***********************empty constructor***********************/
	public ShowDetails()
	{
		super();

	}
	/************************Parameterized constructor********************/
	public ShowDetails(String showId, String showName, String location,
			LocalDate date, int availTicket, float priceTicket) {
		super();
		this.showId = showId;
		this.showName = showName;
		this.location = location;
		this.date = date;
		this.availTicket = availTicket;
		this.priceTicket = priceTicket;
	}
	/**************************Getter Setters***********************/
	public String getShowId() {
		return showId;
	}

	public void setShowId(String showId) {
		this.showId = showId;
	}

	public String getShowName() {
		return showName;
	}

	public void setShowName(String showName) {
		this.showName = showName;
	}

	public String getLocation() {
		return location;
	}

	public void setLocation(String location) {
		this.location = location;
	}

	public LocalDate getDate() {
		return date;
	}

	public void setDate(LocalDate date) {
		this.date = date;
	}

	public int getAvailTicket() {
		return availTicket;
	}

	public void setAvailTicket(int availTicket) {
		this.availTicket = availTicket;
	}

	public float getPriceTicket() {
		return priceTicket;
	}

	public void setPriceTicket(float priceTicket) {
		this.priceTicket = priceTicket;
	}

}
