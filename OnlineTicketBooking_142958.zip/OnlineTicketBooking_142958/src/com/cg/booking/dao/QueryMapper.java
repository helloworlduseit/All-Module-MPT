package com.cg.booking.dao;

public interface QueryMapper 
{
	String SELECT_ALL_BOOKDETAILS="SELECT * FROM ShowDetails";
	String UPDATE_BOOKDETAILS = " UPDATE ShowDetails SET AvSeats=AvSeats-? WHERE SHOWID=?";
}
