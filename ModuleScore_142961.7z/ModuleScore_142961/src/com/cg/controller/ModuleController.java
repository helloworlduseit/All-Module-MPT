package com.cg.controller;
import java.io.IOException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.cg.dto.AssessmentScore;
import com.cg.dto.TraineeBean;
import com.cg.exception.ModuleScoreException;
import com.cg.service.ModuleService;
import com.cg.service.ModuleServiceImpl;

@WebServlet(urlPatterns={"/add","/insert"})
public class ModuleController extends HttpServlet 
{
	private static final long serialVersionUID = 1L;
    
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		doPost(request,response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		String url = request.getServletPath();
		String targetUrl = "";
		ModuleService modSer = new ModuleServiceImpl();
		HttpSession sess=request.getSession();
		switch(url)
		{
		case "/add":
			try 
			{
				List<TraineeBean> alist=modSer.getAllTrainee();
				sess.setAttribute("alist", alist);
				targetUrl="AddAssessment.jsp";
			} 
			catch (Exception e) 
			{
				request.setAttribute("error", e.getMessage());
				targetUrl="Error.jsp";
			}
			break;
			
		case "/insert":
		{
			String id=request.getParameter("tid");
			String name=request.getParameter("mname");
			String mpt=request.getParameter("txtMpt");
			String mtt=request.getParameter("txtMtt");
			String assn=request.getParameter("txtAss");
			
			AssessmentScore asc=new AssessmentScore();
			asc.setTraineeId(Integer.parseInt(id));
			asc.setModuleName((String)name);
			asc.setMptNo(Integer.parseInt(mpt));
			asc.setMttNo(Integer.parseInt(mtt));
			asc.setAssMarks(Integer.parseInt(assn));
			
			asc.setTotal(Integer.parseInt(mpt)+Integer.parseInt(mtt)+Integer.parseInt(assn));
			sess.setAttribute("aid", id);
			sess.setAttribute("nm", name);
			
			sess.setAttribute("total", asc.getTotal());
			int total=asc.getTotal();
			int tt=modSer.getGrade(total);
			asc.setGrade(tt);
			sess.setAttribute("grade", tt);
			try {
				long data=modSer.setScoreDetails(asc);
				targetUrl="ModuleScore.jsp";
			} 
			catch (ModuleScoreException e) 
			{
				
				e.printStackTrace();
			}
		}
			
		}
		RequestDispatcher disp = request.getRequestDispatcher(targetUrl);
		disp.forward(request, response);
	}
}
