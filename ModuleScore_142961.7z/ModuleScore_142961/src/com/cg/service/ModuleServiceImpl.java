package com.cg.service;
import java.util.List;
import com.cg.dao.ModuleDao;
import com.cg.dao.ModuleDaoImpl;
import com.cg.dto.AssessmentScore;
import com.cg.dto.TraineeBean;
import com.cg.exception.ModuleScoreException;

public class ModuleServiceImpl implements ModuleService
{
	ModuleDao modDao = new ModuleDaoImpl();
	@Override
	public List<TraineeBean> getAllTrainee() throws ModuleScoreException 
	{
		return modDao.getAllTrainee();
	}

	@Override
	public long setScoreDetails(AssessmentScore assScore)
			throws ModuleScoreException 
	{
		return modDao.setScoreDetails(assScore);
	}

	@Override
	public List<AssessmentScore> getAllScore()
			throws ModuleScoreException 
	{
		return modDao.getAllScore();
	}
	public int getGrade(int total)
	{
		int tt=0;
		if(total>=0&&total<50)
		{
			tt=0;
		}
		else if(total>=50&&total<60)
		{
			tt=1;
		}
		else if(total>=60&&total<70)
		{
			tt=2;
		}
		else if(total>=70&&total<80)
		{
			tt=3;
		}
		else if(total>=80&&total<90)
		{
			tt=4;
		}
		else if(total>=90&&total<100)
		{
			tt=5;
		}
		return tt;
	}
}
