package com.cg.dto;

public class AssessmentScore 
{
	private int traineeId;
	private String moduleName;
	private int mptNo;
	private int mttNo;
	private int assMarks;
	private int total;
	private int grade;
/***********************empty constructor***********************/
	public AssessmentScore() 
	{
		super();
	}
/************************Parameterized constructor********************/
public AssessmentScore(int traineeId, String moduleName, int mptNo,
		int mttNo, int assMarks, int total,int grade) 
{
	super();
	this.traineeId = traineeId;
	this.moduleName = moduleName;
	this.mptNo = mptNo;
	this.mttNo = mttNo;
	this.assMarks = assMarks;
	this.total = total;
	this.grade= grade;
}
/**************************Getter Setters***********************/
public int getTraineeId() 
{
	return traineeId;
}
public void setTraineeId(int traineeId) 
{
	this.traineeId = traineeId;
}
public String getModuleName() 
{
	return moduleName;
}
public void setModuleName(String moduleName) 
{
	this.moduleName = moduleName;
}
public int getMptNo() 
{
	return mptNo;
}
public void setMptNo(int mptNo) 
{
	this.mptNo = mptNo;
}
public int getMttNo()
{
	return mttNo;
}
public void setMttNo(int mttNo) 
{
	this.mttNo = mttNo;
}
public int getAssMarks() 
{
	return assMarks;
}
public void setAssMarks(int assMarks) 
{
	this.assMarks = assMarks;
}
public int getTotal() 
{
	return total;
}
public void setTotal(int total) 
{
	this.total = total;
}
public int getGrade() {
	return grade;
}
public void setGrade(int grade) 
{
	this.grade = grade;
}

}
